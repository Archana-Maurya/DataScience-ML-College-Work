import numpy as np
yields=np.array([
    [1600,4000,8000,2800],   
    [3200,8100,3300,1100],   
    [8000,8400,1000,4000]
])
print(yields)
increasedyields=yields*1.10
print(increasedyields)
wheatyields=increasedyields[0]
print(wheatyields)
averagepercrop=increasedyields.mean(axis=1)
print(averagepercrop)
greaterthan3000=increasedyields[increasedyields>3000]
print(greaterthan3000)

