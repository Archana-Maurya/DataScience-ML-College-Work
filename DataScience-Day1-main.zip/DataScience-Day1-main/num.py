import numpy as np

prices = np.array([100, 200, 300, 400])
prices = prices * 1.10
print(prices)

#Broadcasting
arr=np.array([[10,20,30],[40,50,60]])
arr2=arr+5
print (arr2)

#Indexing and slicing
arr=np.array([10,20,30,40,50])
print(arr[2])
print(arr[1:4])


sales_day1=np.array([120, 85, 60])
sales_day2=np.array([150, 90, 75])
#Total sales per product
total_sales=sales_day1 + sales_day2
print(total_sales)
#Percentage growth
percentage_growth=((sales_day2-sales_day1)/sales_day1)*100
print(percentage_growth)
#Product with highest growth
highest_growth_index = np.argmax(percentage_growth)
print(highest_growth_index)
   
temps=np.array([
    [25, 28, 30],
    [22, 24, 26],
    [30, 32, 33],
    [27, 29, 31],
    [20, 21, 23]
])
#Convert to Fahrenheit
fahrenheit=temps * 9/5 + 32
print(fahrenheit)
#Add correction factor
correction=np.array([1, -1, 0])
adjusted_temps=temps+correction
print(adjusted_temps)
bp = np.array([
    [120, 80],
    [135, 85],
    [140, 90],
    [110, 70],
    [125, 75]
])

#Extract systolic values (first column)
systolic=bp[:,0]
print(systolic)
#Patients with systolic > 130
high_bp=bp[systolic>130]
print(high_bp)
#Replace diastolic < 80 with 80
bp[bp[:,1]<80,1]=80
print(bp)

yields = np.array([
    [2.5, 3.0, 1.8],
    [2.8, 3.2, 2.0],
    [3.1, 2.9, 2.2],
    [2.6, 3.1, 1.9]
])
#Increase yields of second region
yields[1]=yields[1] + np.array([0.2, 0.3, 0.1])
print(yields)
#Multiply last column (Crop C) by 1.1
yields[:, 2] = yields[:, 2] * 1.1
print(yields)
#Highest average yield crop
avg_yield=np.mean(yields, axis=0)
highest_crop_index=np.argmax(avg_yield)
print(avg_yield)
print(highest_crop_index)

scores=np.array([
    [85,78,92],
    [88,74,90],
    [70,65,80],
    [95,89,96]
])
#Top two students
top_two=scores[:2]
print(top_two)
# All Math scores (first column)
math_scores=scores[:,0]
print(math_scores)
# Students who scored>90 in Science (third column)
science_high=scores[scores[:,2]>90]
print(science_high)

matrix=np.array([[1,2,3],
                 [4,5,6],
                 [7,8,9]])
print(matrix[0])
print(matrix[:,1])
print(matrix[1:,0:2])