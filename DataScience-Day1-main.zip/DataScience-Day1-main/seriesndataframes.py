import pandas as pd
data={
    "Name":["A","B","C"],
    "salary":[50000,60000,55000]
}
df=pd.DataFrame(data)
print(df)