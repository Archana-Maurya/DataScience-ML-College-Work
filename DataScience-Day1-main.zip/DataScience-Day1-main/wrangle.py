import pandas as pd
import numpy as np
customers=pd.read_csv("Customers.csv")
sales=pd.read_excel("Sales.xlsx")
support=pd.read_csv("Support.csv")
 print(customers.shape)
 print(sales.shape)
 print(support.shape)
 print(customers.columns)
 print(sales.columns)
 print(support.columns)
 print(customers.isnull().sum())
 print(sales.isnull().sum())
 print(support.isnull().sum())
customers["Signup Date"]=pd.to_datetime(customers["Signup Date"])
sales["Order Date"]=pd.to_datetime(sales["Order Date"])
customers["Age"]=customers["Age"].fillna(customers["Age"].median())
customers.rename(columns={"Customer ID":"CustomerID"}, inplace=True)
sales.rename(columns={"Customer ID":"CustomerID"}, inplace=True)
support.rename(columns={"Customer ID":"CustomerID"}, inplace=True)
price_array=sales["Price"].to_numpy()
sales["DiscountedPrice"]=price_array*0.9
sales["Revenue"]=sales["Quantity"]*sales["Price"]
jan_2025_orders=sales[
    (sales["Order Date"].dt.year==2025) &
    (sales["Order Date"].dt.month==1)
]
first_10_sales=sales.iloc[:10]
print(jan_2025_orders)
print(first_10_sales)
north_customers=customers[customers["Region"]=="North"]
high_value_orders=sales[sales["Revenue"]>10000]
print(north_customers)
print(high_value_orders)
sorted_customers=customers.sort_values(by="Signup Date")
sorted_sales=sales.sort_values(by="Revenue",ascending=False)
sales_with_region=sales.merge(customers[["CustomerID","Region"]], on="CustomerID",how="left")
avg_revenue_region=sales_with_region.groupby("Region")["Revenue"].mean()
avg_resolution_issue=support.groupby("Issue Type")["Resolution Time"].mean()
print(avg_revenue_region)
print(avg_resolution_issue)
merged=sales.merge(customers,on="CustomerID",how="left") \
              .merge(support,on="CustomerID",how="left")
clv=sales.groupby("CustomerID")["Revenue"].sum().reset_index()
clv.rename(columns={"Revenue":"CLV"},inplace=True)
avg_res_customer=support.groupby("CustomerID")["Resolution Time"].mean().reset_index()
avg_res_customer.rename(columns={"Resolution Time": "AvgResolutionTime"},inplace=True)
final_data=merged.merge(clv, on="CustomerID", how="left")\
                   .merge(avg_res_customer, on="CustomerID", how="left")
final_data.to_csv("Cleaned_Data.csv",index=False)
print("Cleaned_Data.csv exported successfully")



